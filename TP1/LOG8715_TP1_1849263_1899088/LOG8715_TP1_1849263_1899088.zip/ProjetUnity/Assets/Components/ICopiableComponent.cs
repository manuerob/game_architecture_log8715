﻿
using System;

public interface ICopiableComponent : IComponent, ICloneable
{

}
